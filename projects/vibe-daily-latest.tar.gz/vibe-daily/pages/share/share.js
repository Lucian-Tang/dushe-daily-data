const api = require('../../utils/api.js');

Page({
  data: {
    title: '',
    quote: '',
    type: 'social',
    posterUrl: '',
    ready: false
  },

  onLoad(options) {
    this.setData({
      title: decodeURIComponent(options.title || '今日毒舌'),
      quote: decodeURIComponent(options.quote || '今天的毒舌，明天的谈资'),
      type: options.type || 'social'
    });
    this.drawPoster();
  },

  drawPoster() {
    const { title, quote, type } = this.data;

    const query = wx.createSelectorQuery().in(this);
    query.select('#posterCanvas')
      .fields({ node: true, size: true })
      .exec((res) => {
        if (!res[0]) return;
        const canvas = res[0].node;
        const ctx = canvas.getContext('2d');
        const W = 600;
        const H = 900;
        canvas.width = W;
        canvas.height = H;

        // 背景：暗黑紫底
        const bg = ctx.createLinearGradient(0, 0, W, H);
        bg.addColorStop(0, '#1A1035');
        bg.addColorStop(0.5, '#1A0A2E');
        bg.addColorStop(1, '#0F0A1E');
        ctx.fillStyle = bg;
        ctx.fillRect(0, 0, W, H);

        // 顶部装饰线
        const topGrad = ctx.createLinearGradient(0, 0, W, 0);
        topGrad.addColorStop(0, '#7C3AED');
        topGrad.addColorStop(0.5, '#06B6D4');
        topGrad.addColorStop(1, '#7C3AED');
        ctx.fillStyle = topGrad;
        ctx.fillRect(0, 0, W, 6);

        // 顶部装饰圆
        ctx.save();
        ctx.beginPath();
        ctx.arc(W / 2, 80, 40, 0, 2 * Math.PI);
        const orbGrad = ctx.createRadialGradient(W / 2, 80, 0, W / 2, 80, 40);
        orbGrad.addColorStop(0, 'rgba(6,182,212,0.8)');
        orbGrad.addColorStop(1, 'rgba(124,58,237,0.3)');
        ctx.fillStyle = orbGrad;
        ctx.fill();
        ctx.restore();

        // Logo 文字
        ctx.font = 'bold 32px sans-serif';
        ctx.fillStyle = '#06B6D4';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('🔥 毒舌日报', W / 2, 150);

        // 分割线
        const lineGrad = ctx.createLinearGradient(60, 0, W - 60, 0);
        lineGrad.addColorStop(0, 'rgba(124,58,237,0)');
        lineGrad.addColorStop(0.5, 'rgba(124,58,237,0.6)');
        lineGrad.addColorStop(1, 'rgba(124,58,237,0)');
        ctx.beginPath();
        ctx.moveTo(60, 180);
        ctx.lineTo(W - 60, 180);
        ctx.strokeStyle = lineGrad;
        ctx.lineWidth = 1;
        ctx.stroke();

        // Lucia 金句标签
        ctx.font = '22px sans-serif';
        ctx.fillStyle = '#A78BFA';
        ctx.textAlign = 'center';
        ctx.fillText('❝ Lucia 毒舌金句 ❞', W / 2, 220);

        // 引用正文
        ctx.font = 'italic 36px sans-serif';
        ctx.fillStyle = '#C4B5FD';
        ctx.textAlign = 'center';

        // 换行处理
        const maxW = W - 80;
        const words = quote.split('');
        let line = '';
        let lines = [];
        for (let c of words) {
          const test = line + c;
          const met = ctx.measureText(test);
          if (met.width > maxW) {
            lines.push(line);
            line = c;
          } else {
            line = test;
          }
        }
        lines.push(line);

        const lineH = 52;
        const startY = 280;
        lines.slice(0, 5).forEach((l, i) => {
          ctx.fillText(l, W / 2, startY + i * lineH);
        });

        // 新闻标题区域
        const y1 = startY + Math.min(lines.length, 5) * lineH + 50;

        // 底部分隔
        ctx.beginPath();
        ctx.moveTo(60, y1);
        ctx.lineTo(W - 60, y1);
        ctx.strokeStyle = 'rgba(6,182,212,0.3)';
        ctx.lineWidth = 1;
        ctx.stroke();

        // 新闻标题
        ctx.font = 'bold 28px sans-serif';
        ctx.fillStyle = '#E2E8F0';
        ctx.textAlign = 'center';
        const titleWords = title.split('');
        let titleLine = '';
        let titleLines = [];
        for (let c of titleWords) {
          const test = titleLine + c;
          if (ctx.measureText(test).width > maxW) {
            titleLines.push(titleLine);
            titleLine = c;
          } else {
            titleLine = test;
          }
        }
        titleLines.push(titleLine);
        titleLines.slice(0, 3).forEach((l, i) => {
          ctx.fillText(l, W / 2, y1 + 30 + i * 42);
        });

        // 小程序码占位区
        const qrY = H - 240;
        ctx.fillStyle = 'rgba(255,255,255,0.08)';
        ctx.fillRect(W / 2 - 70, qrY, 140, 140);
        ctx.font = '20px sans-serif';
        ctx.fillStyle = 'rgba(255,255,255,0.3)';
        ctx.fillText('[小程序码]', W / 2, qrY + 75);

        // 底部文字
        ctx.font = '22px sans-serif';
        ctx.fillStyle = 'rgba(255,255,255,0.35)';
        ctx.fillText('今天的毒舌，明天的谈资', W / 2, H - 50);

        // 底部装饰线
        ctx.fillStyle = topGrad;
        ctx.fillRect(0, H - 6, W, 6);

        // 导出图片
        setTimeout(() => {
          wx.canvasToTempFilePath({
            canvas,
            quality: 1,
            success: (r) => {
              this.setData({ posterUrl: r.tempFilePath, ready: true });
            },
            fail: (e) => {
              console.error('[share] canvasToTempFilePath failed', e);
              this.setData({ ready: true });
            }
          });
        }, 100);
      });
  },

  savePoster() {
    if (!this.data.posterUrl) return;
    wx.saveImageToPhotosAlbum({
      filePath: this.data.posterUrl,
      success: () => {
        wx.showToast({ title: '海报已保存', icon: 'success' });
      },
      fail: () => {
        wx.showToast({ title: '保存失败', icon: 'none' });
      }
    });
  },

  goBack() {
    wx.navigateBack();
  }
});