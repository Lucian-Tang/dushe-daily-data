const api = require('../../utils/api.js');

Page({
  data: {
    tabs: [
      { key: 'all', name: '全部', icon: '📰' },
      { key: 'industry', name: '行业', icon: '🏭' },
      { key: 'dev', name: '开发者', icon: '💻' },
      { key: 'social', name: '社会', icon: '🌐' }
    ],
    activeTab: 'all',
    listData: [],
    loading: false,
    emotionData: null,
    canvasReady: false
  },

  onLoad() {
    this.fetchData();
    this.fetchEmotion();
  },

  async fetchData() {
    this.setData({ loading: true });
    const data = await api.fetchDailyList(this.data.activeTab);
    this.setData({ listData: data, loading: false });
  },

  async fetchEmotion() {
    const data = await api.fetchEmotionData();
    this.setData({ emotionData: data });
    // 等 canvas 节点渲染完再画
    setTimeout(() => this.drawRadar(), 300);
  },

  switchTab(e) {
    const key = e.currentTarget.dataset.key;
    if (key === this.data.activeTab) return;
    this.setData({ activeTab: key, listData: [] });
    this.fetchData();
  },

  onCardTap(e) {
    const { id } = e.detail;
    wx.navigateTo({
      url: `/pages/detail/detail?id=${id}`
    });
  },

  // 画情绪雷达图
  drawRadar() {
    const d = this.data.emotionData;
    if (!d) return;

    const query = wx.createSelectorQuery().in(this);
    query.select('#radarCanvas')
      .fields({ node: true, size: true })
      .exec((res) => {
        if (!res[0]) return;
        const canvas = res[0].node;
        const ctx = canvas.getContext('2d');
        const w = res[0].width;
        const h = res[0].height;
        const cx = w / 2;
        const cy = h / 2;
        const r = Math.min(w, h) * 0.38;

        canvas.width = w * 2;
        canvas.height = h * 2;
        ctx.scale(2, 2);

        const dimensions = [
          { label: '愤怒', value: d.anger },
          { label: '娱乐', value: d.entertainment },
          { label: '讨论', value: d.discussion },
          { label: '焦虑', value: d.anxiety },
          { label: '正能量', value: d.positive }
        ];
        const n = dimensions.length;
        const angleStep = (2 * Math.PI) / n;

        // 背景五边形（3层）
        for (let layer = 1; layer <= 3; layer++) {
          const rr = r * (layer / 3);
          ctx.beginPath();
          for (let i = 0; i < n; i++) {
            const a = i * angleStep - Math.PI / 2;
            const x = cx + rr * Math.cos(a);
            const y = cy + rr * Math.sin(a);
            i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
          }
          ctx.closePath();
          ctx.strokeStyle = 'rgba(124,58,237,0.2)';
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }

        // 画维度连线
        dimensions.forEach((dim, i) => {
          const a = i * angleStep - Math.PI / 2;
          ctx.beginPath();
          ctx.moveTo(cx, cy);
          ctx.lineTo(cx + r * Math.cos(a), cy + r * Math.sin(a));
          ctx.strokeStyle = 'rgba(124,58,237,0.25)';
          ctx.lineWidth = 0.5;
          ctx.stroke();

          // 标签
          const lx = cx + (r + 22) * Math.cos(a);
          const ly = cy + (r + 22) * Math.sin(a);
          ctx.font = '10px sans-serif';
          ctx.fillStyle = '#A78BFA';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(dim.label, lx, ly);
        });

        // 填数据区域
        const points = dimensions.map((dim, i) => {
          const a = i * angleStep - Math.PI / 2;
          const rr = (dim.value / 100) * r;
          return { x: cx + rr * Math.cos(a), y: cy + rr * Math.sin(a) };
        });

        ctx.beginPath();
        points.forEach((p, i) => {
          i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y);
        });
        ctx.closePath();
        ctx.fillStyle = 'rgba(124,58,237,0.35)';
        ctx.fill();
        ctx.strokeStyle = '#7C3AED';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // 数据点
        points.forEach(p => {
          ctx.beginPath();
          ctx.arc(p.x, p.y, 3, 0, 2 * Math.PI);
          ctx.fillStyle = '#06B6D4';
          ctx.fill();
        });
      });
  }
});