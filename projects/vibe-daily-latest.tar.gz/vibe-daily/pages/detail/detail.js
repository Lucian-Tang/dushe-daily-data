const api = require('../../utils/api.js');

Page({
  data: {
    article: null,
    typeName: '',
    shareTip: false
  },

  onLoad(options) {
    this.loadArticle(options.id);
  },

  async loadArticle(id) {
    const article = await api.fetchDetail(id);
    const typeMap = { industry: '行业', dev: '开发者', social: '社会' };
    this.setData({
      article,
      typeName: typeMap[article?.type] || ''
    });
  },

  goBack() {
    wx.navigateBack();
  },

  onShareAppMessage() {
    const { article } = this.data;
    if (!article) return {};
    return {
      title: `【毒舌点评】${article.title}`,
      path: `/pages/detail/detail?id=${article.id}`,
      imageUrl: ''
    };
  },

  goToShare() {
    const { article } = this.data;
    if (!article) return;
    wx.navigateTo({
      url: `/pages/share/share?id=${article.id}&title=${encodeURIComponent(article.title)}&quote=${encodeURIComponent(article.quote)}&type=${article.type}`
    });
  }
});