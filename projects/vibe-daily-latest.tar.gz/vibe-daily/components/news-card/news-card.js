Component({
  properties: {
    item: {
      type: Object,
      value: {}
    }
  },

  data: {
    typeName: ''
  },

  lifetimes: {
    attached() {
      const typeMap = {
        industry: '行业',
        dev: '开发者',
        social: '社会'
      };
      this.setData({
        typeName: typeMap[this.properties.item.type] || '未知'
      });
    }
  },

  methods: {
    onTap() {
      this.triggerEvent('tap', this.properties.item);
    }
  }
});
