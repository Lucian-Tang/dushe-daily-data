/**
 * API层 - 对接真实JSON数据
 */
const loader = require('./data-loader.js');

// 真实数据源
function fetchDailyList(type = 'all') {
  return new Promise((resolve) => {
    let data;
    switch (type) {
      case 'industry':
        data = loader.loadArticles();
        break;
      case 'dev':
        data = loader.loadDev();
        break;
      case 'social':
        data = loader.loadSocial();
        break;
      default:
        data = loader.loadAll();
    }
    // 模拟异步
    setTimeout(() => resolve(data), 100);
  });
}

function fetchDetail(id) {
  return new Promise((resolve) => {
    const all = loader.loadAll();
    const item = all.find(d => d.id === id);
    setTimeout(() => resolve(item || null), 50);
  });
}

// 导出情绪数据
function fetchEmotionData() {
  return Promise.resolve(loader.EMOTION_DATA);
}

module.exports = {
  fetchDailyList,
  fetchDetail,
  fetchEmotionData
};