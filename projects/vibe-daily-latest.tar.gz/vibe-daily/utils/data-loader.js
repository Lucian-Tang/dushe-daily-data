/**
 * 数据加载器 - 统一读取三类JSON并转成小程序格式
 * 自动生成 type 标签和辅助字段
 */

const fs = wx.getFileSystemManager();

// Lucia 毒舌点评样例（后续接 AI API）
const LUCHA_COMMENTS = {
  industry: [
    '大厂又在内卷了，卷到最后发现用户在刷另一个App。',
    '行业报告写得漂亮，股价跌得也很漂亮。',
    '这个赛道已经红海到发紫了，还有人往里冲。',
    'PPT融资时代过去了，现在流行的是——PPT裁员。',
    '风口上的猪摔死了，风还在吹。'
  ],
  dev: [
    '又一个"革命性"框架，官网文档还是Notion写的。',
    'CV工程师的新利器：Copilot帮你写，HR负责砍。',
    '这个开源项目 star 10k，issue 9k，活跃度全靠吵架。',
    '代码跑通了？先别高兴，可能是玄学。',
    '重构三次以上的项目，都是历史遗留问题。'
  ],
  social: [
    '这届年轻人真难懂，上一秒躺平，下一秒飞盘。',
    '热搜买的，评论区控的，水军是AI的。',
    '真相不重要，情绪到位才重要。',
    '互联网嘴替：替你说完了，你说不用负责。',
    '这瓜保熟吗？不保，但流量管够。'
  ]
};

// 五维情绪数据（sample）
const EMOTION_DATA = {
  anger: 65,
  entertainment: 82,
  discussion: 71,
  anxiety: 58,
  positive: 74
};

// Sample 兜底数据（真实文件不可用时使用）
const SAMPLE_ITEMS = [
  {type:'industry',title:'大厂纷纷入局AI大模型，行业洗牌加速',content:'阿里、字节、百度相继发布大模型，行业竞争进入白热化阶段',quote:'不是大模型选择时代，是时代选择了大模型——问题是，谁来买单？',hotScore:9862,pubTime:'2小时前'},
  {type:'industry',title:'新能源车企价格战持续，卖一辆亏一辆成常态',content:'特斯拉降价引发连锁反应，国产新势力被迫跟进',quote:'价格战的尽头是：谁先撑不住谁先出局，其他都是陪跑的。',hotScore:8721,pubTime:'3小时前'},
  {type:'dev',title:'TypeScript 5.4发布：新特性让类型推断更智能',content:'独立声明类型、NoInfer工具类型等重磅更新',quote:'JS的弱类型是技术债，TS不过是给债主一张延期支票。',hotScore:6543,pubTime:'5小时前'},
  {type:'dev',title:'AI代码助手卷到飞起，Copilot最大对手出现',content:'JetBrains AI Assistant全面升级，免费版功能直接对标Copilot付费版',quote:'你以为买的是效率提升？不，你买的是焦虑缓解剂。',hotScore:7234,pubTime:'6小时前'},
  {type:'social',title:'年轻人为什么不爱去KTV了？',content:'剧本杀、露营、飞盘之后，下一个社交方式是什么',quote:'KTV衰落的真相：不是年轻人不爱唱歌，是爱唱歌的那批人老了。',hotScore:5432,pubTime:'8小时前'},
  {type:'social',title:'直播带货退潮，头部主播相继停播',content:'行业红利消退，头部效应见顶，中小主播生存艰难',quote:'直播带货的真相：品牌亏本赚吆喝，主播稳赚不赔。',hotScore:6123,pubTime:'10小时前'}
];

// 格式化时间
function formatTime(dateStr) {
  if (!dateStr) return '未知';
  const date = new Date(dateStr);
  const now = new Date();
  const diff = now - date;
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  if (hours < 1) return '刚刚';
  if (hours < 24) return `${hours}小时前`;
  if (days < 7) return `${days}天前`;
  return `${date.getMonth() + 1}/${date.getDate()}`;
}

// 生成唯一ID
function genId(type, index) {
  return `${type}_${index}_${Date.now()}`;
}

// 获取随机Lucia点评
function getRandomLuciaComment(type) {
  const list = LUCHA_COMMENTS[type] || LUCHA_COMMENTS.social;
  return list[Math.floor(Math.random() * list.length)];
}

// 计算热度值（从content长度等简单推导）
function calcHotScore(item) {
  const str = JSON.stringify(item.content || item.title || '');
  return Math.floor((str.length * 37 + Math.random() * 500));
}

// 统一转换格式
function normalize(raw, type) {
  if (!raw || !raw.title) return null;
  return {
    id: genId(type, Math.random().toString(36).substr(2, 6)),
    type,
    title: raw.title,
    summary: raw.content ? raw.content.replace(/<[^>]+>/g, '').substring(0, 120) + '...' : raw.title,
    quote: getRandomLuciaComment(type),
    hotScore: calcHotScore(raw),
    pubTime: formatTime(raw.published || raw.pubTime),
    source: raw.source || '',
    url: raw.url || '',
    raw: raw
  };
}

/**
 * 加载行业日报
 */
function loadArticles() {
  try {
    const content = fs.readFileSync('/root/.openclaw/workspace/data/raw_articles_20260507.json', 'utf8');
    const list = JSON.parse(content);
    return (list || []).map(item => normalize(item, 'industry')).filter(Boolean);
  } catch (e) {
    console.warn('[data-loader] loadArticles 本地文件不可用，使用sample数据');
    return SAMPLE_ITEMS.filter(i => i.type === 'industry').map(item => ({
      id: genId('industry', item.title),
      ...item, source:'样例', url:'', raw:{title:item.title, content:item.content}
    }));
  }
}

/**
 * 加载开发者日报
 */
function loadDev() {
  try {
    const content = fs.readFileSync('/root/.openclaw/workspace/data/raw_dev_20260507.json', 'utf8');
    const list = JSON.parse(content);
    return (list || []).map(item => normalize(item, 'dev')).filter(Boolean);
  } catch (e) {
    console.warn('[data-loader] loadDev 本地文件不可用，使用sample数据');
    return SAMPLE_ITEMS.filter(i => i.type === 'dev').map(item => ({
      id: genId('dev', item.title),
      ...item, source:'样例', url:'', raw:{title:item.title, content:item.content}
    }));
  }
}

/**
 * 加载社会新闻
 */
function loadSocial() {
  try {
    const content = fs.readFileSync('/root/.openclaw/workspace/data/raw_social_20260507.json', 'utf8');
    const list = JSON.parse(content);
    return (list || []).map(item => normalize(item, 'social')).filter(Boolean);
  } catch (e) {
    console.warn('[data-loader] loadSocial 本地文件不可用，使用sample数据');
    return SAMPLE_ITEMS.filter(i => i.type === 'social').map(item => ({
      id: genId('social', item.title),
      ...item, source:'样例', url:'', raw:{title:item.title, content:item.content}
    }));
  }
}

/**
 * 加载全部数据
 */
function loadAll() {
  const articles = loadArticles();
  const dev = loadDev();
  const social = loadSocial();
  return [...articles, ...dev, ...social].sort((a, b) => b.hotScore - a.hotScore);
}

module.exports = {
  loadAll,
  loadArticles,
  loadDev,
  loadSocial,
  EMOTION_DATA,
  LUCHA_COMMENTS,
  getRandomLuciaComment,
  normalize
};