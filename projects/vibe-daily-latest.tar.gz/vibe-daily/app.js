App({
  onLaunch() {
    console.log('毒舌日报启动')
  }
})
